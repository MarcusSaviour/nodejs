export function isNegative(value: number): boolean {
  return value < 0;
}
