export enum AddressType {
  Billing = 'BILLING',
  Shipping = 'SHIPPING',
}
