import { atom } from 'jotai';
export const displayHeaderSearchAtom = atom(false);
