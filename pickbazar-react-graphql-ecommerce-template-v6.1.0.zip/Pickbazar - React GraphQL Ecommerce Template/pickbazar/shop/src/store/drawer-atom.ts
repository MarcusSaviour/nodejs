import { atom } from 'jotai';

export const drawerAtom = atom({ display: false, view: '' });
