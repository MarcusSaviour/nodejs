import { atom } from 'jotai';
export const stickyShortDetailsAtom = atom(false);
