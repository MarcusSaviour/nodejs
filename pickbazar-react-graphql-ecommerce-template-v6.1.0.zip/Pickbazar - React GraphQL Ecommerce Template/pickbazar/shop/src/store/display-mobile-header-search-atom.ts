import { atom } from 'jotai';
export const displayMobileHeaderSearchAtom = atom(false);
